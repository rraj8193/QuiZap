package com.example.quizap;

import android.content.Intent;
import android.net.Uri;
import android.os.Parcel;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.internal.firebase_auth.zzff;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseUserMetadata;
import com.google.firebase.auth.UserInfo;
import com.google.firebase.auth.zzy;
import com.google.firebase.auth.zzz;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RegistrationForm extends AppCompatActivity {
    EditText name;
    EditText email;
    EditText password,confpassword;
    EditText collegeid,teacherid,enrollment;
    CheckBox facultybox,studentbox;
    Button registerbtn;
    FirebaseAuth fauth;
    FirebaseFirestore fstore;
    boolean valid = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_form);

        fauth = FirebaseAuth.getInstance();
        fstore = FirebaseFirestore.getInstance();
        name = findViewById(R.id.c_namefield);
        email = findViewById(R.id.c_emailfield);
        password= findViewById(R.id.c_passwordfield);
        confpassword = findViewById((R.id.c_confpasswordfield));
        collegeid = findViewById(R.id.collegeidfield);
        facultybox = findViewById(R.id.facultyaccessbtn);
        studentbox = findViewById(R.id.studentaccessbtn);
        teacherid = findViewById((R.id.teacherid));
        enrollment = findViewById(R.id.enrollmentno);
        registerbtn = findViewById(R.id.register);

        facultybox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundbutton, boolean isChecked) {
                if(compoundbutton.isChecked()){
                    studentbox.setChecked(false);
                    teacherid.setVisibility(View.VISIBLE);
                    enrollment.setVisibility(View.GONE);
                }
                else
                {
                    teacherid.setVisibility(View.GONE);
                }
            }
        });
        studentbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundbutton, boolean isChecked) {
                if(compoundbutton.isChecked()){
                    facultybox.setChecked(false);
                    enrollment.setVisibility(View.VISIBLE);
                    teacherid.setVisibility(View.GONE);
                }
                else
                {
                    enrollment.setVisibility(View.GONE);
                }
            }
        });

        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkField(name);
                checkField(email);
                checkField(password);
                checkField(confpassword);
                checkField(collegeid);
                checkField(teacherid);
                checkField(enrollment);

                if(valid){
                    fauth.createUserWithEmailAndPassword(email.getText().toString(),password.getText().toString()).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {
                            Toast.makeText(RegistrationForm.this, "Account Created Successfully", Toast.LENGTH_SHORT).show();
                            FirebaseUser user = fauth.getCurrentUser();
                            DocumentReference df = fstore.collection("Users").document(user.getUid());
                            Map<String,Object> userinfo = new HashMap<>();
                            userinfo.put("FullName",name.getText().toString());
                            userinfo.put("Email",email.getText().toString());
                            userinfo.put("CollegeID",collegeid.getText().toString());
                            if(facultybox.isChecked()){
                                userinfo.put("Account Type","1");
                                userinfo.put("FacultyId",teacherid.getText().toString());
                            }
                            else if (studentbox.isChecked()){
                                userinfo.put("Account Type","0");
                                userinfo.put("StudentID",enrollment.getText().toString());
                            }
                            df.set(userinfo);
                            finish();

                            }

                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(RegistrationForm.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                        }
                    });
                }



                if(!(facultybox.isChecked() || studentbox.isChecked())){
                    Toast.makeText(RegistrationForm.this, "Select the account type", Toast.LENGTH_SHORT).show();
                    return;
                }

            }
        });
    }
    public void viewLoginPage(View view){
        Intent login = new Intent(this, LogIn.class);
        startActivity(login);
    }
    public boolean checkField(EditText textfield){
        if(textfield.getText().toString().isEmpty()){
            textfield.setError("Error");
            valid = false;
        }
        else {
            valid = true;
        }
        return valid;
    }
}
package com.example.quizap;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class LogIn extends AppCompatActivity {

    CheckBox collegelogincheckbox,communitylogincheckbox;
    EditText collegeusername,collegepassword,collegeid;
    EditText communityusername,communitypassword;
    Button login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        collegelogincheckbox = findViewById(R.id.collegelogincheckbox);
        communitylogincheckbox = findViewById(R.id.communitylogincheckbox);
        collegeid = findViewById(R.id.collegeidloginfield);
        collegeusername = findViewById(R.id.collegeusernamefield);
        collegepassword = findViewById(R.id.collegeuserpasswordfield);
        communityusername = findViewById(R.id.communityusernamefield);
        communitypassword = findViewById(R.id.communityuserpasswordfield);
        login = findViewById(R.id.loginuserbutton);

        collegelogincheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(buttonView.isChecked()){
                    communitylogincheckbox.setChecked(false);
                    collegeid.setVisibility(View.VISIBLE);
                    collegeusername.setVisibility(View.VISIBLE);
                    collegepassword.setVisibility(View.VISIBLE);
                }
                else{
                    collegeid.setVisibility(View.GONE);
                    collegeusername.setVisibility(View.GONE);
                    collegepassword.setVisibility(View.GONE);
                }
            }
        });

        communitylogincheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(buttonView.isChecked()){
                    collegelogincheckbox.setChecked(false);
                    communityusername.setVisibility(View.VISIBLE);
                    communitypassword.setVisibility(View.VISIBLE);
                }
                else{
                    communityusername.setVisibility(View.GONE);
                    communitypassword.setVisibility(View.GONE);
                }
            }
        });

    }
    public void viewRegistrationPage(View view) {
        Intent signin = new Intent(this, SignIn.class);
        startActivity(signin);
    }
}
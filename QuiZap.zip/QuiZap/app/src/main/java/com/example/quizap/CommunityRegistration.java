package com.example.quizap;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class CommunityRegistration extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_community_registration);
    }
}
package com.example.quizap;

import android.content.Intent;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void viewRegistrationPage(View view){
        Intent signin = new Intent(this, SignIn.class);
        startActivity(signin);
    }
    public void viewLoginPage(View view){
        Intent login = new Intent(this, LogIn.class);
        startActivity(login);
    }
}
package com.example.quizap;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class SignIn extends AppCompatActivity {
    Button collegesigninbutton;
    Button communitysigninbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        collegesigninbutton = findViewById(R.id.collegesigninbtn);
        communitysigninbutton = findViewById(R.id.communityusersigninbutton);

        collegesigninbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CollegeSignIn();
            }
        });
        communitysigninbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CommunitySignIn();
            }
        });
    }
    public void CollegeSignIn(){
        Intent collegesignin = new Intent (this, RegistrationForm.class);
        startActivity(collegesignin);
    }
    public void CommunitySignIn(){
        Intent communitysignin = new Intent(this,CommunityRegistration.class);
        startActivity(communitysignin);
    }
}